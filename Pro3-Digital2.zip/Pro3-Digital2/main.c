#include <stdint.h>
#include <stdbool.h>
//#include "inc/tm4c123gh6pm.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"

#define XTAL 16000000

char Data;
int estado1;
int estado2;
int estado3;
int estado4;

int main(void)
{
    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN |
                   SYSCTL_XTAL_16MHZ); //80MHZ

    //Enable GPIO
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //Outputs and Inputs
    GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);   //Infrarrojos

    GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7);  //leds verdes
    GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4);   //leds rojos
    GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_6);  //led rojo
/*
    //Timer0 Config
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    //Timer0 as periodic
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    //Timer0 at 0.5Hz
    TimerLoadSet(TIMER0_BASE, TIMER_A, (uint32_t)((SysCtlClockGet()) / 2) - 1);
    //Enable timer0 interrupt
    IntEnable(INT_TIMER0A);
    //Timer0 interrupt exist
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    //Activate timer0
    TimerEnable(TIMER0_BASE, TIMER_A);*/
/*
    //USART0 Config
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    // Enable UART0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    // Configure GPIO Pins for UART mode.
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    //Activate UART
    UARTConfigSetExpClk(
                UART0_BASE, SysCtlClockGet(), 115200,
                (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    //Activate UART0
    UARTEnable(UART0_BASE);*/

    //UART1 Config
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    // Enable UART1
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1);
    // Configure GPIO Pins for UART mode.
    GPIOPinConfigure(GPIO_PB0_U1RX);
    GPIOPinConfigure(GPIO_PB1_U1TX);
    GPIOPinTypeUART(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    //Activate UART1
    UARTConfigSetExpClk(
                UART1_BASE, SysCtlClockGet(), 115200,
                (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    //Enable UART1 interrupt
    IntEnable(INT_UART1);
    //UART1 interrupt exist
    UARTIntEnable(UART1_BASE, UART_INT_RX | UART_INT_TX);
    //Activate UART1
    UARTEnable(UART1_BASE);

    //Enable global interrupts
    IntMasterEnable();
	while(1){
	    //Infrarojos
	    estado1 = GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_0);
	    estado2 = GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_1);
	    estado3 = GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_2);
	    estado4 = GPIOPinRead(GPIO_PORTD_BASE, GPIO_PIN_3);

	    //Leds
	    if(estado1 == 0){
	        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_4,GPIO_PIN_4);   //Led verde
	        GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_2, 0);           //Led rojo
	    }else if(estado1 == 1){
	        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_4,0);            //Led verde
	        GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_2, GPIO_PIN_2);  //Led rojo
	    }

        if(estado2 == 0){
            GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_5,GPIO_PIN_5);   //Led verde
            GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, 0);           //Led rojo
        }else if(estado2 == 2){
            GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_5,0);            //Led verde
            GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, GPIO_PIN_3);  //Led rojo
        }

        if(estado3 == 0){
            GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6,GPIO_PIN_6);   //Led verde
            GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_4, 0);           //Led rojo
        }else if(estado3 == 4){
            GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6,0);            //Led verde
            GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_4, GPIO_PIN_4);  //Led rojo
        }

        if(estado4 == 0){
            GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7,GPIO_PIN_7);   //Led verde
            GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, 0);           //Led rojo
        }else if(estado4 == 8){
            GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7,0);            //Led verde
            GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, GPIO_PIN_6);  //Led rojo
        }
	}
}
/*
void Timer0IntHandler(void){

    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    //UARTCharPutNonBlocking(UART0_BASE,estado1);

    if(Data == 'k'){
    //if(Data == 'h'){
        UARTCharPutNonBlocking(UART1_BASE, estado1);
        UARTCharPutNonBlocking(UART1_BASE, estado2);
        UARTCharPutNonBlocking(UART1_BASE, estado3);
        UARTCharPutNonBlocking(UART1_BASE, estado4);
    }
}
*/
void UART1IntHandler(void){
    UARTIntClear(UART1_BASE, UART_INT_RX | UART_INT_TX);
    Data = UARTCharGetNonBlocking(UART1_BASE);

    //if(Data == 'k'){
    if(Data == 'h'){
        UARTCharPutNonBlocking(UART1_BASE, estado1);
        UARTCharPutNonBlocking(UART1_BASE, estado2);
        UARTCharPutNonBlocking(UART1_BASE, estado3);
        UARTCharPutNonBlocking(UART1_BASE, estado4);
    }
    //UARTCharPutNonBlocking(UART0_BASE,Data);
}

